# WoTDetect
WoT Detect implementation in python
