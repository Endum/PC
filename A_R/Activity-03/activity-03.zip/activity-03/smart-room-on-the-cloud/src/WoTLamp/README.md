# WoTLamp
WoT Lamp implementation in python
