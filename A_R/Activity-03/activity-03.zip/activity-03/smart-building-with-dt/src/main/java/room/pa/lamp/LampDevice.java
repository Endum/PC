package room.pa.lamp;

public interface LampDevice {
	
	void on();
	void off();

}
