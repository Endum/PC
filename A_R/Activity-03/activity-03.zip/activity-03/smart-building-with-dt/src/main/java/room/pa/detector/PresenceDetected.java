package room.pa.detector;

import common.Event;

public class PresenceDetected extends Event {

	public PresenceDetected(long timestamp) {
		super(timestamp);
	}

}
