package room.consumer.detector;

import room.consumer.DTAPI;

public interface DetectorDTAPI extends DTAPI{
    
}
