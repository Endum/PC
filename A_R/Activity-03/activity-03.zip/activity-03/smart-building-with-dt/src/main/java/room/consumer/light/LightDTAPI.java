package room.consumer.light;

import room.consumer.DTAPI;

public interface LightDTAPI extends DTAPI{
    
}
