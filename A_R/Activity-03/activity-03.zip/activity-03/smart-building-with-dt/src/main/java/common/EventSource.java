/**
 *  
 *  Basic interfaces for devices generating events
 * 
 */
package common;

public interface EventSource {

	void register(Controller c);

}
