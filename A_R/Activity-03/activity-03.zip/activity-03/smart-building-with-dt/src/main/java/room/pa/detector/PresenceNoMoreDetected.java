package room.pa.detector;

import common.Event;

public class PresenceNoMoreDetected extends Event {

	public PresenceNoMoreDetected(long timestamp) {
		super(timestamp);
	}

}
