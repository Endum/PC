package common;

public class TimerEvent extends Event {

	public TimerEvent(long timestamp) {
		super(timestamp);
	}

}
