package room.pa.detector;

public interface DetectorDevice {

    boolean presenceDetected();

}
