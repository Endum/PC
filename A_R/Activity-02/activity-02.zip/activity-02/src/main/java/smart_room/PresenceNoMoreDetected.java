package smart_room;

public class PresenceNoMoreDetected extends Event {

	public PresenceNoMoreDetected(long timestamp) {
		super(timestamp);
	}

}
