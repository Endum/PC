package smart_room;

public class PresenceDetected extends Event {

	public PresenceDetected(long timestamp) {
		super(timestamp);
	}

}
