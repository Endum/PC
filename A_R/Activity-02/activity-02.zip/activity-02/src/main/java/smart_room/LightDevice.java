package smart_room;

public interface LightDevice {
	
	void on();
	void off();

}
