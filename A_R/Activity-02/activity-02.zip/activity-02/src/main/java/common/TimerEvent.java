package common;

import smart_room.Event;

public class TimerEvent extends Event {

	public TimerEvent(long timestamp) {
		super(timestamp);
	}

}
