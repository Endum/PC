/**
 *  
 *  Basic interfaces for devices generating events
 * 
 */
package smart_room;

public interface EventSource {

	void register(Controller c);

}
