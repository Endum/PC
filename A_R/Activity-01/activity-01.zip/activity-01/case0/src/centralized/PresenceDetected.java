package smart_room.centralized;

import smart_room.Event;

public class PresenceDetected extends Event {

	public PresenceDetected(long timestamp) {
		super(timestamp);
	}

}
