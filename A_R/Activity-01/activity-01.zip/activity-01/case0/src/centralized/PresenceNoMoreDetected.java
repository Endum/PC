package smart_room.centralized;

import smart_room.Event;

public class PresenceNoMoreDetected extends Event {

	public PresenceNoMoreDetected(long timestamp) {
		super(timestamp);
	}

}
