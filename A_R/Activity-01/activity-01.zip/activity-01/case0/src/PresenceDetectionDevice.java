package smart_room;

public interface PresenceDetectionDevice extends EventSource {
	
	boolean presenceDetected();

}
