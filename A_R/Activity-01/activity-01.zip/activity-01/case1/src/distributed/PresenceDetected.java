package smart_room.distributed;

import smart_room.Event;

public class PresenceDetected extends Event {

	public PresenceDetected(long timestamp) {
		super(timestamp);
	}

}
