package smart_room.distributed;

import smart_room.Event;

public class PresenceNoMoreDetected extends Event {

	public PresenceNoMoreDetected(long timestamp) {
		super(timestamp);
	}

}
